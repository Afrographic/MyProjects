var initswiper = {
	container:'.swiper_data_container',
	display_mode:'images',
	data:['images/1.jpg','images/2.jpg','images/3.jpg','images/4.jpg','images/5.jpg','images/6.jpg','images/7.jpg','images/8.jpg','images/9.jpg'],
	// display_mode:'text',
	// data:['un Lorem ipsum dolor sit amet, consectetur adipisicing elit. Amet explicabo porro, nam nobis rerum ad asperiores delectus suscipit ab dolorum nihil eveniet, similique nisi harum blanditiis officia quasi obcaecati enim vel, quos veritatis tempore.','Lorem ipsum dolor sit amet, consectetur adipisicing elit. Voluptate incidunt ipsa quod, quam cupiditate.','Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nemo facilis quia ab, voluptas quidem reprehenderit sapiente rerum reiciendis.','Lorem ipsum dolor sit amet, consectetur adipisicing elit. Soluta eveniet ipsum recusandae consectetur similique, amet error quisquam minus cupiditate accusantium explicabo ab aut quaerat fuga at animi minima dolor sunt. Dicta, quisquam officia cumque aliquid porro repellendus vel earum eius.'],
	loop:true,
	autoplay:false,
	delay:2000,
	show_controls:false
}